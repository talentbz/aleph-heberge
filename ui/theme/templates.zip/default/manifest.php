<?php
$theme = array();
$theme['admin'] = true;
$theme['client'] = true;